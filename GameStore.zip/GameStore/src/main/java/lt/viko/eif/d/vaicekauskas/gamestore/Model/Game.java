package lt.viko.eif.d.vaicekauskas.gamestore.Model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;

import java.util.Objects;

@Entity
public class Game {

    private @Id
    @GeneratedValue int id;
    private String gameName;
    private String gameGenre;
    private int releaseYear;
    private String publisher;
    private Double price;

    public Game(){};

    public Game(int id, String gameName, String gameGenre, int releaseYear, String publisher, Double price) {
        this.id = id;
        this.gameName = gameName;
        this.gameGenre = gameGenre;
        this.releaseYear = releaseYear;
        this.publisher = publisher;
        this.price = price;
    }

    public Game(String gameName, String gameGenre, int releaseYear, String publisher, Double price) {
        this.gameName = gameName;
        this.gameGenre = gameGenre;
        this.releaseYear = releaseYear;
        this.publisher = publisher;
        this.price = price;
    }

    public int getId() {return id;}

    public void setId(int id) {this.id = id;}

    public String getGameName() {return gameName;}

    public void setGameName(String gameName) {this.gameName = gameName;}

    public String getGameGenre() {return gameGenre;}

    public void setGameGenre(String gameGenre) {this.gameGenre = gameGenre;}

    public int getReleaseYear() {return releaseYear;}

    public void setReleaseYear(int releaseYear) {this.releaseYear = releaseYear;}

    public String getPublisher() {return publisher;}

    public void setPublisher(String publisher) {this.publisher = publisher;}

    public double getPrice() {return price;}

    public void setPrice(double price) {this.price = price;}

    @Override
    public boolean equals(Object o){
        if(this == o){
            return true;
        }
        if (!(o instanceof Game)){
            return false;
        }
        Game game = (Game) o;
        return Objects.equals(this.id, game.id)
                && Objects.equals(this.gameGenre, game.gameGenre)
                && Objects.equals(this.gameName, game.gameName)
                && Objects.equals(this.price, game.price)
                && Objects.equals(this.releaseYear, game.releaseYear)
                && Objects.equals(this.publisher, game.publisher);
    }

    @Override
    public int hashCode(){
        return Objects.hash(this.id, this.gameGenre, this.gameName, this.price, this.releaseYear, this.publisher);
    }

    @Override
    public String toString() {
        return String.format("\tTrip:\n\t\t\t\t" + "Organization gameGenre = %s\n\t\t\t\t" + "gameGenre = %s\n\t\t\t\t" +
                        "releaseYear = %s\n\t\t\t\t" + "Trip Duration = %s\n\t\t\t\t" + "price = %s\n\t\t\t\t",
                this.gameName,
                this.gameGenre,
                this.releaseYear,
                this.publisher,
                this.price);
    }

}
