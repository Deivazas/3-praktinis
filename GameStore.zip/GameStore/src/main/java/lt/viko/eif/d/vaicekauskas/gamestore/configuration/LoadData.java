package lt.viko.eif.d.vaicekauskas.gamestore.configuration;

import lt.viko.eif.d.vaicekauskas.gamestore.OrderRepos;
import lt.viko.eif.d.vaicekauskas.gamestore.Model.Order;
import lt.viko.eif.d.vaicekauskas.gamestore.Model.Game;
import lt.viko.eif.d.vaicekauskas.gamestore.Model.Customer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.List;

@Configuration
public class LoadData {

    private static final Logger log = LoggerFactory.getLogger(LoadData.class);

    @Bean
    CommandLineRunner initData(OrderRepos repository) {
        return args -> {
            loadSampleData(repository);
        };
    }

    private void loadSampleData(OrderRepos repository) {
        Game game1 = new Game("Escape from Tarkov", "Shooter", 2014, "BSG", 34.99);
        Customer customer1 = new Customer("Jhon", "Mayers", "Mayers@gmail.com", 812321421, 23);
        Order order1 = new Order(List.of(game1), List.of(customer1), "2013-05-23");

        Game game2 = new Game("Squad", "Shooter", 2015, "Eneba", 26.99);
        Customer customer01 = new Customer("Roger", "Harris", "Harris@gmail.com", 24142133, 24);
        Customer customer02 = new Customer("Olaf", "Grey", "Grey@gmail.com", 212441421, 25);
        Order order2 = new Order(List.of(game2), List.of(customer01, customer02), "2019.02.23");

        repository.save(order1);
        log.info("Loaded order: " + order1);

        repository.save(order2);
        log.info("Loaded order: " + order2);
    }
}
